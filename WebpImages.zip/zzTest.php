<?php

  include 'CardDictionary.php';

  echo(HasBloodDebt("MON160"));
echo(strval(round(microtime(true) * 1000)));

?>

