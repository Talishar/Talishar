<?php

  function BossCharacterPieces()
  {
    return 2;
  }

?>