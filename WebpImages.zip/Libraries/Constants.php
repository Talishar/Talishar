<?php

  $INF_CONST_TIMESTAMP_LENGTH = 11;

?>

